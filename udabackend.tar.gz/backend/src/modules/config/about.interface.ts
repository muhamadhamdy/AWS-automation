export interface AboutInfo {
  version: string;
  environment: string;
}
